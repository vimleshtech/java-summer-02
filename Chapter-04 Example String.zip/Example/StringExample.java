package Example;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {

		//String example: 
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter data ");
		String name = s.nextLine();
		
		//convert to upper case
		System.out.println(name.toUpperCase());
		
		//Convert to lower case 
		System.out.println(name.toLowerCase());
		
		//get count/length
		int l = name.length();
		System.out.println(l);
		
		//replace 
		System.out.println(name.replace("a", "xy"));
		
		//find position
		int ps = name.indexOf("m");
		System.out.println(ps);
		
		//cut the string: raman
		System.out.println(name.substring(2,5));
		
		//split : break the string in array 
		String n[] = name.split(" "); //raman sinha = {"raman","sinha"}
		System.out.println(n[0]);
		System.out.println(n[1]);
		
		//WAP to get space count 
		int sc = name.length() - name.replace(" ", "").length();
		System.out.println(sc);
		
		
		
	}
}
