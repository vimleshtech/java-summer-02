package Example;
import java.util.Scanner;
public class q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter the string=");
		String name =s.nextLine();
		
		System.out.println("enter char ");
		String c =s.nextLine();
		
		System.out.println(name.replace(c, c.toUpperCase()));
		
		System.out.println(name.replace(c, c.toLowerCase()));
		
		
		
	}

}
