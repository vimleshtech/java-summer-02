package Example;
import java.util.Scanner;

public class q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner s = new Scanner(System.in);
		
		System.out.println("enter data ");
		String name = s.nextLine();
		
		int i = name.length() - name.replace(" ", "").length();
		System.out.println(i);
		
		int j=name.length()- name.replace("\t", "").length();
		System.out.println(j);
		
		int k=name.length()- name.replace("\n", "").length();
		System.out.println(k);
	}

}
