package Example;

import java.util.Scanner;

import java.util.Scanner;
public class q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
     Scanner s = new Scanner(System.in);
		
		System.out.println("enter the string=");
		String name =s.nextLine();
		
		
		int l = name.length();
		System.out.println(l);
		
		int sc =name.length()-(name.length() -name.replace(" ", "").length());
		System.out.println(sc);
	}

}
