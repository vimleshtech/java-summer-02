package example;

public class LoopExample {

	public static void main(String[] args) {
		
		
		//while loop
		int i=1;
		
		while(i<10) { //conditioin 
			
			//System.out.println(i);
			System.out.print(i);
			
			i++; //steps or incrementer
		}
		//wap to print series in reverse order
		i =10;
		while(i>0) {
			System.out.println(i);
			i--;
		}
				
		
		//wap to print sum of all even and odd numbers between 1 to 100
		int se=0,so=0;
		
		i =1;
		while(i<=100) {
			
			if(i%2 ==0) {
				se +=i; //se=se+i
			}
			else {
				so +=i;
			}
			i++;
		}
			
		System.out.println(se);
		System.out.println(so);
	}

}
