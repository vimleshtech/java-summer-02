package example;
         import  java.util.Scanner;

public class sec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	         int i,n,m,f;
	         
	         Scanner s=new Scanner(System.in) ;
	         
             System.out.println("enter the value of n=");             
             n = s.nextInt();
             
             System.out.println("enter the value of m=");
             m=s.nextInt();
             
         
         for(i=n;i<m;i++)
         {
        	
        	 System.out.println(i);
        	 
         }
         
         
         
        
	}

}
