package example;

public class first {

	public static void main(String[] args) {
		
        int i=1,sum=0,avg;
       while(i<=100)
        {
        	System.out.println(i);
        	sum=sum+i;
        	i++;
        	
        }
       
       System.out.println("sum of nos="+sum);
       
       
       	
	}

}
