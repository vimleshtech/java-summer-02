package example;

public class Additon {

	public static void main(String[] arg) {
		
		
		int a,b,c;
		
		a =90;
		b =78;
		
		c = a+b;
		
		System.out.println("sum of two numbers "+c);
		
		//multiplication
		c =a*b;
		System.out.println("mul of two numbers "+c);
		
		
		
		
	}
}
