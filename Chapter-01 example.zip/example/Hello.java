package example;

public class Hello
{

	public static void main(String[] a) 
	{
		
		//Print message
		System.out.println("Hi , this is my first code");
		
	
		String name ="Divya";
		System.out.println(name);
		System.out.println("your name is "+name);
		
	}
	
}
