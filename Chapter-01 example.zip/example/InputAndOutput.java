package example;

import java.util.Scanner;

public class InputAndOutput {

	public static void main(String[] args) {

		Scanner o = new Scanner(System.in); 
		
		int a,b,c;
		
		System.out.println("enter number ");
		a = o.nextInt();  //nextInt() is function to read int value 
		
		System.out.println("enter number ");
		b = o.nextInt();  //nextInt() is function to read int value
		
		
		//show greater number
		if(a>b) {
			System.out.println("a is greater than b");
		}else {
			System.out.println("b is greater than a");
		}
		
				
		
		

	}

}
