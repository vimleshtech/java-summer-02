package example;

import java.util.Scanner;

public class squareno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		java.util.Scanner o=new Scanner(System.in);
		
		int a,b,c,d,e;
		
		 System.out.println("enter no.");
		 a=o.nextInt();
		 
		 System.out.println("enter no.");
		 b=o.nextInt();
		 
		 System.out.println("enter no.");
		 c=o.nextInt();
		 
		 System.out.println("enter no.");
		 d=o.nextInt();
		 
		 
		 b=a*a*a+b*b*b + c*c*c;
		 d =d*d*d;
		 System.out.println(b);
		 System.out.println(d);
		 
		 if(b==d)
		 {
			 System.out.println("condition is match");
		 }
		 
		 else {
			 System.out.println("condition is not match");
		 }
		 
		 

	}

}
