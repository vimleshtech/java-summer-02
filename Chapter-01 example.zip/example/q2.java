package example;
import java.util.Scanner;


public class q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner o = new Scanner(System.in);
		
		int rn,a,b,c,d,e,t;
		String name;
		
		System.out.println("enter rollno= ");
		rn = o.nextInt();
		
		System.out.println("enter name ");
		name = o.next(); //next to read string
		
		System.out.println("enter mark1 ");
		a = o.nextInt();
		
		
		System.out.println("enter mark2 ");
		b = o.nextInt();
		
		
		System.out.println("enter mark3 ");
		c = o.nextInt();
		
		
		System.out.println("enter mark4 ");
		d = o.nextInt();
		
		
		System.out.println("enter mark5 ");
		e = o.nextInt();
		
		t = a+b+c+d+e;
				
		System.out.println("total score is "+t);
	}

}
